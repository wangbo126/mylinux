#!/bin/bash
arcfilename="archive-"`date +%Y%m%d`".tar.gz"
#echo $arcfilename
arcfilepath=""
files_to_backup="files-to-backup.txt"

while read line
do
    if [ -e $line ];then
        arcfilepath=$arcfilepath" "$line
    fi
done<$files_to_backup

tar zcvf $arcfilename $arcfilepath

