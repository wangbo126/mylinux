# Sed 文本编辑

## 介绍

本次挑战内容是...

## 目标

本次挑战目标是...

本次挑战用到资源如下：

[资源图片1](https://www.shiyanlou.com/test1.png)
![资源图片2](http://www.shiyanlou.com/test2.jpg)

[资源数据1](https://www.shiyanlou.com/test1.tar.gz)
![资源数据2](https://www.shiyanlou.com/test2.tar.gz)

## 提示语

1.首先执行...
1.然后执行...
1.最后得到...